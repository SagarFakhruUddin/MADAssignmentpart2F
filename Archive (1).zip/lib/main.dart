import 'package:flutter/material.dart';
import 'homeWidget.dart' as home;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.amberAccent,
            title: Text('My Home'),
            bottom: TabBar(tabs: [
              Tab(
                text: "All",
              ),
              Tab(
                text: "Dining Room",
              ),
              Tab(
                text: "BedRoom",
              ),
            ]),
          ),
          body: const home.homepage(),
        ),
      ),
    );
  }
}
