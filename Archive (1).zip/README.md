# Smart home control

this application is a frontend interface of a smart home application that allows the user to control diffrent devices in the house. app is still in progress.

## ToDo
* Add tabs for seperate rooms.
* Connect to data base (build the backend).

## How it works

from the home.dart we call the custom buttons that are found in the button.dart, these custom buttons are made so that they have a switch that toggle on touch and change colors from grey(off) and green(on).

## Screen Shots 

![68c34fd2-4501-4114-b59b-0aa84d0e8d52](https://user-images.githubusercontent.com/71787197/171256168-3ab44f6c-f853-4eb9-8f67-6b5932b0be60.jpg)

off

![b402dc95-d997-4089-a6ce-ebfddd0ae89b](https://user-images.githubusercontent.com/71787197/171256193-973072b7-77d5-4853-b614-317f39523193.jpg)

on
